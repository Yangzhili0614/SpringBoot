package com.us.example.bean;

/**
 * Created by yangyibo on 16/12/29.
 * 浏览器向服务器发送的消息使用此类接受
 */
public class Message {
    private String name;

    public String getName(){
        return name;
    }
}